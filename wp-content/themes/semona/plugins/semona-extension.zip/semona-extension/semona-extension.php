<?php
/*
Plugin Name: Semona Extension
Plugin URI: http://themeforest.net/user/Theme-Paradise
Description: Plugin to contain shortcodes and custom post types of the Semona theme.
Author: Theme-Paradise
Author URI: http://themeforest.net/user/Theme-Paradise
Version: 1.4.4
Text Domain: semona-extension
*/

defined( 'ABSPATH' ) or die( 'Do not access this file directly.' );

// Plugin URL
define( 'SM_PLUGIN_URL', plugins_url( '', __FILE__ ) );

// Plugin PATH
define( 'SM_PLUGIN_PATH', ABSPATH . 'wp-content/plugins/semona-extension' );

// Shortcode Class Path
define( 'SM_SHORTCODE_PATH', SM_PLUGIN_PATH . '/shortcodes' );

// Shortcode Class Path
define( 'SM_SHORTCODE_CLASS_PATH', SM_SHORTCODE_PATH . '/classes/' );

// Shortcode Template Path
define( 'SM_SHORTCODE_TEMPLATE_PATH', SM_SHORTCODE_PATH . '/templates/' );

define ( 'DS' , DIRECTORY_SEPARATOR );

require_once( 'inc/init.php' );