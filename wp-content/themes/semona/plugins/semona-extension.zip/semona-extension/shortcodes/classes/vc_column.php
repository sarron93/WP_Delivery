<?php
add_action( 'vc_before_init', 'sm_add_params_vc_column' );
function sm_add_params_vc_column() {
	vc_add_params( 'vc_column', array(
		sm_bg_color_preset_option(),
		sm_background_clip_option(),
		sm_css_animation_class(),
		sm_css_animation_delay()
	) );
}
