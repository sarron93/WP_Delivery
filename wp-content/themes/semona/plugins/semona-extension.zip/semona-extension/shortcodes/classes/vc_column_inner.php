<?php
add_action( 'vc_before_init', 'sm_add_params_vc_column_inner' );
function sm_add_params_vc_column_inner() {
	vc_add_params( 'vc_column_inner', array(
		sm_bg_color_preset_option(),
		sm_background_clip_option(),
		sm_css_animation_class(),
		sm_css_animation_delay(),
	) );
}
