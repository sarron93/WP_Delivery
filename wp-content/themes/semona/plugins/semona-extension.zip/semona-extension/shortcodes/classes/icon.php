<?php

if( !function_exists( 'sm_icon_func' ) ) {
	function sm_icon_func( $atts, $content = null ) {

		$icon = sm_get_icon_from_atts( $atts );
		$output = '<i class="sm-icon ' . $icon . '"></i>';
		return $output;
	}
}

sm_register_shortcode( array (
	'name' => esc_html__( 'Icon', 'semona-extension' ),
	'base' => 'sm_icon',
	//'icon' => SM_PLUGIN_URL . '/assets/images/shortcodes/icon-icon.png',
	'params' => sm_get_icon_options_array(),
) );