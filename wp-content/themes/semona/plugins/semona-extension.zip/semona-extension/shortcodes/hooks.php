<?php

add_action( 'vc_before_init', 'sm_init_vc_iconpicker_filters' );

function sm_init_vc_iconpicker_filters() {
	remove_filter( 'vc_iconpicker-type-fontawesome', 'vc_iconpicker_type_fontawesome' );
	add_filter( 'vc_iconpicker-type-fontawesome', 'sm_iconpicker_type_fontawesome', 20 );

	remove_filter( 'vc_iconpicker-type-entypo', 'vc_iconpicker_type_entypo' );
	add_filter( 'vc_iconpicker-type-entypo', 'sm_iconpicker_type_entypo' );

	remove_filter( 'vc_iconpicker-type-typicons', 'vc_iconpicker_type_typicons' );
	add_filter( 'vc_iconpicker-type-typicons', 'sm_iconpicker_type_typicons' );

	remove_filter( 'vc_iconpicker-type-linecons', 'vc_iconpicker_type_linecons' );
	add_filter( 'vc_iconpicker-type-linecons', 'sm_iconpicker_type_linecons' );
	
	add_filter( 'vc_iconpicker-type-pe_icon_7_stroke', 'sm_iconpicker_type_pe_icon_7_stroke' );
	
	add_filter( 'vc_iconpicker-type-flaticon', 'sm_iconpicker_type_flaticon' );
}

function sm_iconpicker_type_fontawesome( $icons ) {
	$icon_list = sm_get_icon_list();
	return array_merge( $icons, $icon_list['fontawesome']['icons'] );
}

function sm_iconpicker_type_entypo( $icons ) {
	$icon_list = sm_get_icon_list();
	return array_merge( $icons, $icon_list['entypo']['icons'] );
}

function sm_iconpicker_type_typicons( $icons ) {
	$icon_list = sm_get_icon_list();
	return array_merge( $icons, $icon_list['typicons']['icons'] );
}

function sm_iconpicker_type_linecons( $icons ) {
	$icon_list = sm_get_icon_list();
	return array_merge( $icons, $icon_list['linecons']['icons'] );
}

function sm_iconpicker_type_pe_icon_7_stroke( $icons ) {
	$icon_list = sm_get_icon_list();
	return array_merge( $icons, $icon_list['pe_icon_7_stroke']['icons'] );
}

function sm_iconpicker_type_flaticon( $icons ) {
	$icon_list = sm_get_icon_list();
	return array_merge( $icons, $icon_list['flaticon']['icons'] );
}


function sm_filter_footer_style( $tag, $handle ) {
	$footer_stylesheets = array(
		'mediaelement',
		'wp-mediaelement',
		'js_composer_front',
		'sm_flaticon',
		'sm_linecons',
	);
	if ( in_array( $handle, $footer_stylesheets ) )
		return str_replace( 'rel', 'property="stylesheet" rel', $tag );
	return $tag;
}
add_filter( 'style_loader_tag', 'sm_filter_footer_style', 10, 2 );
?>