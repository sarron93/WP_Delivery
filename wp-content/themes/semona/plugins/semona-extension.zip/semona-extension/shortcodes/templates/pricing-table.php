<?php
extract ( shortcode_atts ( array (
		'style' => '',
		'columns' => '4',
		'theme' => '',
		'button_shape' => '',
		'el_class' => ''
), $atts ) );

$style = sm_validate_with_array( $style, sm_get_pricingtable_styles_array() );
$columns = sm_validate_with_array( $columns, sm_get_pricingtable_columns_array() );
$theme = sm_validate_with_array( $theme, sm_get_pricingtable_color_schemes_array() );

$css_class = array( 
	"sm-pricing-table", 
	"sm_content_element clearfix",
	"sm-columns-" . $columns,
	$style,
	$theme
);

$css_class = implode( ' ', $css_class );
$css_class .= sm_get_extra_class( $el_class );

$GLOBALS['sm-pricing-table-style'] = $style;
$GLOBALS['sm-pricing-table-button-shape'] = $button_shape;

$wrapper_attributes = array();
$wrapper_attributes[] = 'class="' . esc_attr( $css_class ) . '"';

?>
<div <?php echo implode( ' ', $wrapper_attributes ); ?>>
	<?php echo sm_js_remove_wpautop( $content, true ); ?>
</div>
