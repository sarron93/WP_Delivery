<?php

extract( shortcode_atts( array(
	'style' => '', // maybe for future version
	'href' => '#',
	'el_class' => ''
), $atts ) );

$css_class = array( 'sm-readmore', 'sm_content_element', 'clearfix' );

$style = sm_validate_with_array( $style, sm_readmore_styles_array() );
$css_class[] = $style;
$css_class = implode( ' ', $css_class );
$css_class .= sm_get_extra_class( $el_class );

$wrapper_attributes = array();
$wrapper_attributes[] = 'class="' . esc_attr( $css_class ) . '"';
?>
<div <?php echo implode( ' ', $wrapper_attributes ); ?>>
	<a href="<?php echo esc_url( $href ); ?>"><?php echo preg_replace( '/<\/?p\>/', '', $content ); ?></a>
</div>