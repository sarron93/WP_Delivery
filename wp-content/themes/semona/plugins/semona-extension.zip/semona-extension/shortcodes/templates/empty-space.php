<?php
extract( shortcode_atts( array(
	'height' => '35px',
	'el_class' => ''
), $atts ) );
$css_class = "sm_empty_space ";

$height = sm_validate_length_unit( $height );

$inline_css = ( (float) $height >= 0.0 ) ? 'height: ' . $height : '';

$css_class .= sm_get_extra_class( $el_class );

$wrapper_attributes = array();
$wrapper_attributes[] = 'class="' . esc_attr( $css_class ) . '"';
if ( !empty( $inline_css ) ) {
	$wrapper_attributes[] = 'style="' . $inline_css . '"';
}

?>
<div <?php echo implode( ' ', $wrapper_attributes ); ?>><span class="sm_empty_space_inner"></span></div>