<?php

extract( shortcode_atts( array(
	'el_class' => '',
), $atts ) );

$css_class = 'sm-multi-scroll-left-side ms-left';
$css_class .= ' ' . sm_get_extra_class( $el_class );
?>
<div class='<?php echo esc_attr( $css_class ) ?>'>
	<?php
	echo sm_js_remove_wpautop( $content ); 
	?>
</div>