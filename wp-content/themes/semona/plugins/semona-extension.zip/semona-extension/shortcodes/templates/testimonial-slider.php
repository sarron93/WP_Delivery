<?php
extract( shortcode_atts( array(
	//'theme' => '',
	'style' => '',
	'bullet_shape' => '',
	'nav_pos' => '',
	'content_fontsize' => '',
	'color' => '',
	'bg_color' => '',
	'name_color' => '',
	'company_color' => '',
	'nav_color' => '',
	'nav_active_color' => '',
	'el_class' => '',
), $atts ) );

$css_class = array( 'sm-testimonials', 'sm_content_element', 'clearfix' );
//$theme = sm_validate_with_array( $theme, sm_get_skins_array( true ) );
//$css_class[] = $theme;
$style = sm_validate_with_array( $style, sm_get_testimonial_styles_array() );
$css_class[] = $style;

$GLOBALS['sm-testimonials-style'] = $style;

$id = sm_shortcode_unique_id( "sm_testimonials" );
$css_gen = new Inline_CSS_Generator( "sm-testimonials", $id );
$scoped_css = '';

$content_fontsize = sm_validate_with_array( $content_fontsize, sm_get_testimonial_font_sizes_array() );
if ( !empty( $content_fontsize ) ) {
	$scoped_css .= $css_gen->css( '.ts-content', array( 'font-size' => $content_fontsize ) );
}
$nav_pos = sm_validate_with_array( $nav_pos, sm_get_nav_position_array() );
if ( empty( $nav_pos ) ) {
	$def_pos_ary = sm_get_def_nav_positions();
	$nav_pos = $def_pos_ary[$style];
}
$css_class[] = $nav_pos;

$css_class = implode( ' ', $css_class );
$css_class .= sm_get_extra_class( $el_class );

if ( !empty( $color ) ) {
	$scoped_css .= $css_gen->css( 
		array( '.ts-name', '.ts-company', '.ts-content', '.ts-info' ),
		array( 'color' => $color ) 
	);

	if ( 'sm-style1' == $style ) {
		$scoped_css .= $css_gen->css_with_self_condition( '.sm-style1', '.content-wrap', array( 'border-color' => $color ) );
		$scoped_css .= $css_gen->css_with_self_condition( '.sm-style1', 
			array( '.avatar-wrap:before', '.content-wrap:before', '.content-wrap:after', '.content-wrap .ts-angle:before', '.content-wrap .ts-angle:after' ),
			array( 'background-color' => $color )
		);
	} else if ( 'sm-style2' == $style ) {
		$scoped_css .= $css_gen->css_with_self_condition( '.sm-style2', '.content-wrap', array( 'border-color' => $color ) );
		$scoped_css .= $css_gen->css_with_self_condition( '.sm-style2', 
			array( '.avatar-wrap:before' ),
			array( 'background-color' => $color )
		);
		$scoped_css .= $css_gen->css_with_self_condition( '.sm-style2', 
			array( '.content-wrap:before', '.content-wrap:after', '.content-wrap .ts-angle:before', '.content-wrap .ts-angle:after' ),
			array( 'background-color' => $color )
		);
	} else if ( 'sm-style3' == $style ) {
		$scoped_css .= $css_gen->css_with_self_condition( '.sm-style3', 
			array( '.avatar-wrap:before', '.avatar-wrap:after', '.avatar-inner' ),
			array( 'border-color' => $color ) 
		);
	} else if ( 'sm-style4' == $style ) {
		$scoped_css .= $css_gen->css_with_self_condition( '.sm-style4', 
			array( '.avatar-wrap:before' ),
			array( 'background-color' => $color )
		);
	} else if ( 'sm-style5' == $style ) {
		$scoped_css .= $css_gen->css_with_self_condition( '.sm-style5', 
			array( '.avatar-wrap:before' ),
			array( 'background-color' => $color )
		);
	}

	if ( empty( $nav_color ) ) {
		$scoped_css .= $css_gen->css( 
			array( '.ts-wrap', '.ts-nav a' ),
			array( 'border-color' => $color ) 
		);
		if ( 'sm-style1' == $style ) {
			$scoped_css .= $css_gen->css_with_self_condition( '.sm-style1', 
				array( '.ts-nav a.selected', '.ts-nav a:hover' ),
				array( 'background-color' => $color . ' !important' )
			);
		}
	}
}
if ( !empty( $bg_color ) ) {
	$scoped_css .= $css_gen->css( '.ts-item-wrap', array( 'background-color' => $bg_color ) );
}

if ( !empty( $nav_color ) ) {
	$scoped_css .= $css_gen->css( 
		array( '.ts-wrap', '.ts-nav a' ),
		array( 'border-color' => $nav_color ) 
	);

	if ( 'sm-style1' == $style && empty( $nav_active_color ) ) {
		$scoped_css .= $css_gen->css_with_self_condition( '.sm-style1', 
			array( '.ts-nav a.selected', '.ts-nav a:hover' ),
			array( 'background-color' => $nav_color . ' !important' )
		);
	}
	if ( 'sm-style4' == $style ) {
		$scoped_css .= $css_gen->css_with_self_condition( '.sm-style4', 
			array( '.ts-nav a' ),
			array( 'background-color' => $nav_color )
		);
	}
}

if ( !empty( $nav_active_color ) ) {
	$scoped_css .= $css_gen->css_with_self_condition( '.' . $style, 
		array( '.ts-nav a.selected', '.ts-nav a:hover' ),
		array( 'background-color' => $nav_active_color . ' !important' )
	);
}

if ( !empty( $name_color ) ) {
	$scoped_css .= $css_gen->css( '.ts-name', array( 'color' => $name_color . ' !important' ) );
}

if ( !empty( $company_color ) ) {
	$scoped_css .= $css_gen->css( '.ts-company', array( 'color' => $company_color . ' !important' ) );
}

$bullet_shape = sm_validate_with_array( $bullet_shape, sm_get_nav_bullet_shapes_array() );
$bullet_class = array( 'ts-nav', $bullet_shape );
$bullet_class = implode( ' ', $bullet_class );

$wrapper_attributes = array();
$wrapper_attributes[] = 'class="' . esc_attr( $css_class ) . '"';
$wrapper_attributes[] = 'id="' . esc_attr( $id ) . '"';
?>
<div <?php echo implode( ' ', $wrapper_attributes ); ?>>
<?php sm_the_scoped_css( $scoped_css ); ?>
	<div class="container">
	<?php if ( 'sm-pos-above' == $nav_pos ) : ?>
		<div class="<?php echo esc_attr( $bullet_class ); ?>"></div>
	<?php endif; ?>
		<div class="testimonials-wrap">
			<?php echo sm_js_remove_wpautop( $content, true ); ?>
		</div>
	</div>
	<?php if ( 'sm-pos-above' != $nav_pos ) : ?>
	<div class="<?php echo esc_attr( $bullet_class ); ?>"></div>
	<?php endif; ?>
</div>