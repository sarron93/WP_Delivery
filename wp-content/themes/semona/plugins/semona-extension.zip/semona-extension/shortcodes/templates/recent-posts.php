<?php

extract( shortcode_atts( array(
	'row_count' => '2',
	'categories' => false,
	'el_class' => '',
), $atts ) );

$query_args = array();
$query_args['posts_per_page'] = $row_count * 2;
$query_args['post_status'] = array( 'publish', 'private' );
if( $categories ) {
	$query_args['category__in'] = explode( ',', $categories );
}
$query_args['ignore_sticky_posts'] = '1';
$query_args['has_password'] = false;
$query = new WP_Query( $query_args );

echo '<div class="sm-sc-recent-posts sm-related-posts sm_content_element">';
echo '<div class="row">';
if( $query->have_posts() ) {

	while( $query->have_posts() ):
		$query->the_post();
		if( has_post_thumbnail() ) {
			get_template_part( 'templates/blog/related/content' );
		} else {
			get_template_part( 'templates/blog/related/content', 'no-image' );
		}
	endwhile;
}
echo '</div>';
echo '</div>';