<?php

extract( shortcode_atts( array(
	'css' => '',
	'el_class' => '',
), $atts ) );

$css_class = 'sm-multi-scroll-section ms-section';
$css_class .= ' ' . sm_get_extra_class( $el_class );
$css_class .= ' ' . vc_shortcode_custom_css_class( $css );
?>
<div class='<?php echo esc_attr( $css_class ) ?>'>
	<div class='sm-multi-scroll-section-wrapper'>
		<?php
		echo sm_js_remove_wpautop( $content ); 
		?>
	</div>
</div>