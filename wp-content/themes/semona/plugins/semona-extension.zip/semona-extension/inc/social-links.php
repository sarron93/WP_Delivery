<?php

global $sm_social_links_array;
$sm_social_links_array = array(
	'twitter' => array(
		'name' => esc_html__( 'Twitter', 'semona-extension' ),
		'icon' => 'fa fa-twitter',
	),
	'facebook' => array(
		'name' => esc_html__( 'Facebook', 'semona-extension' ),
		'icon' => 'fa fa-facebook',
	),
	'google_plus' => array(
		'name' => esc_html__( 'Google+', 'semona-extension' ),
		'icon' => 'fa fa-google-plus',
	),
	'linkedin' => array(
		'name' => esc_html__( 'Linkedin', 'semona-extension' ),
		'icon' => 'fa fa-linkedin',
	),
	'instagram' => array(
		'name' => esc_html__( 'Instagram', 'semona-extension' ),
		'icon' => 'fa fa-instagram',
	),
	'dribbble' => array(
		'name' => esc_html__( 'Dribble', 'semona-extension' ),
		'icon' => 'fa fa-dribbble',
	),
	'tumblr' => array(
		'name' => esc_html__( 'Tumblr', 'semona-extension' ),
		'icon' => 'fa fa-tumblr',
	),
	'reddit' => array(
		'name' => esc_html__( 'Reddit', 'semona-extension' ),
		'icon' => 'fa fa-reddit',
	),
	'youtube' => array(
		'name' => esc_html__( 'Youtube', 'semona-extension' ),
		'icon' => 'fa fa-youtube-play',
	),
	'vimeo' => array(
		'name' => esc_html__( 'Vimeo', 'semona-extension' ),
		'icon' => 'fa fa-vimeo-square',
	),
	'pinterest' => array(
		'name' => esc_html__( 'Pinterest', 'semona-extension' ),
		'icon' => 'fa fa-pinterest-p',
	),
	'flickr' => array(
		'name' => esc_html__( 'Flickr', 'semona-extension' ),
		'icon' => 'fa fa-flickr',
	),
	'skype' => array(
		'name' => esc_html__( 'Skype', 'semona-extension' ),
		'icon' => 'fa fa-skype',
	),
	'behance' => array(
		'name' => esc_html__( 'Behance', 'semona-extension' ),
		'icon' => 'fa fa-behance-square',
	),
);

function sm_get_social_links_array() {
	global $sm_social_links_array;
	return $sm_social_links_array;
}