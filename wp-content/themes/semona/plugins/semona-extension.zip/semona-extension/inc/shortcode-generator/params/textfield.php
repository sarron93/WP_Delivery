<?php
if( !empty( $param['std'] ) ) {
	$std_value = $param['std'];
} else if( !empty( $param['value'] ) ) {
	$std_value = $param['value'];
} else {
	$std_value = '';
}
?>
<input type="text" class="crsg-param-value crsg-block-element" data-param-name="<?php echo ( $param['param_name'] ); ?>" value="<?php echo esc_attr( $std_value ); ?>">