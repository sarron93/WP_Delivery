<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<body>

	<div id="crsg-popup">
		<div class='crsg-side'>
			<?php foreach( crsg_shortcodes() as $shortcode ) : ?>
				<a href='#' class='crsg-shortcode-link' data-code='<?php echo esc_attr( $shortcode['base'] ); ?>'><?php echo ( $shortcode['name'] ) ?></a>
			<?php endforeach; ?>
		</div>
		
		<div class='crsg-body'>
			<?php foreach( crsg_shortcodes() as $shortcode ) : ?>
				<div class='crsg-shortcode-params crsg-shortcode-<?php echo esc_attr( $shortcode['base'] ); ?>' data-shortcode-base='<?php echo esc_attr( $shortcode['base'] ); ?>'>
					<?php
					foreach( $shortcode['params'] as $param ) {
						crsg_output_params( $param );
					}
					?>
				</div>
			<?php endforeach; ?>
		</div>
		
		<div class='crsg-footer'>
			<a href="#" id="crsg-insert-shortcode-button" title="<?php echo esc_html__( 'Insert Shortcode', 'semona-extension' ); ?>"><?php echo esc_html__( 'Insert Shortcode', 'semona-extension' ); ?></a>
		</div>
	</div>
	
</body>
</html>