<?php
$params = $param['params'];
?>
<div class='crsg-param-group-container' data-param-name="<?php echo ( $param['param_name'] ); ?>">
	<div class='crsg-param-groups'>
		<?php
		crsg_output_param_group( $params, false, 'prototype' );
		if( !empty( $param['value'] ) ) {
			$std_values = json_decode( urldecode( $param['value'] ), true );
			foreach( $std_values as $values ) {
				crsg_output_param_group( $params, $values );
			}
		}
		?>
	</div>
	<a href='#' class='crsg-param-group-add'>
		<i class='fa fa-plus'></i>
	</a>
</div>