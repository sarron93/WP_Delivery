<?php
if( !empty( $param['std'] ) ) {
	$std_value = $param['std'];
} else if( !empty( $param['value'] ) ) {
	$std_value = $param['value'];
} else {
	$std_value = '';
}
?>
<select class="crsg-param-value crsg-block-element" data-param-name="<?php echo ( $param['param_name'] ); ?>">
	<?php foreach( $param['value'] as $name => $value ) : 
	?><option value="<?php echo ( $value ); ?>"<?php echo ( $std_value == $value ) ? ' selected' : ''; ?>><?php echo ( $name ) ?></option><?php 
	endforeach; ?>
</select>