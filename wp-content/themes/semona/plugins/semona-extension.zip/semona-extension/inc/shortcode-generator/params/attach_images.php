<div class="crsg-attach-images clearfix">
	<input type="hidden" class="crsg-param-value" data-param-name="<?php echo ( $param['param_name'] ); ?>" value="">
	<div class="crsg-image-block crsg-image-thumb crsg-prototype">
		<img src="">
		<i class='fa fa-close'></i>
	</div>
	<div class="crsg-image-block crsg-image-add">
		<i class='fa fa-plus'></i>
	</div>
</div>