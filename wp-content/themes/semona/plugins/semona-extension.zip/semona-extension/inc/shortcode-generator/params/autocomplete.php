<div class="crsg-block-element">
	<select multiple="multiple" class="crsg-param-value crsg-autocomplete" data-param-name="<?php echo ( $param['param_name'] ); ?>"></select>
</div>
