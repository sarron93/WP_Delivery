<?php
$label = esc_html__( 'Yes', 'semona-extension' );
$value = 'true';
if( !empty( $param['value'] ) && is_array( $param['value'] ) ) {
	foreach( $param['value'] as $label_ => $value_ ) {
		$label = $label_;
		$value = $value_;
		break;
	}
}
if( !empty( $param['std'] ) ) {
	$std_value = $param['std'];
	$std_checked = ( $std_value == $value ) ? true : '';
} else {
	$std_checked = '';
}
?>
<input type="checkbox" class="crsg-param-checkbox" data-value="<?php echo ( $value ) ?>"><?php echo ( $label ) ?></input>
<input type="hidden" class="crsg-param-value" data-param-name="<?php echo ( $param['param_name'] ); ?>" value="<?php echo ( $std_checked ) ?>">