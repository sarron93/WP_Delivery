<div class="sm-tab_id crsg-block-element">
	<input data-param-name="<?php echo esc_attr( $param['param_name'] );
		?>" class="crsg-param-value <?php echo esc_attr( $param['param_name'] . ' ' . $param['type'] ); 
		?>" type="hidden" value="" />
	<label class="crsg-param-label"></label>
</div>