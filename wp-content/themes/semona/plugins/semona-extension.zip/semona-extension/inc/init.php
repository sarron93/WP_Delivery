<?php

/* Declare Custom Post Type: Portfolio */
require_once( SM_PLUGIN_PATH . '/inc/portfolio.php' );

/* Add social link options to author profile */
require_once( SM_PLUGIN_PATH . '/inc/author-info.php' );

/* Icon Picker Resources */
require_once( SM_PLUGIN_PATH . '/inc/iconpicker.php' );

/* Social Link Settings */
require_once( SM_PLUGIN_PATH . '/inc/social-links.php' );

/* Twitter Auth */
require_once ( SM_PLUGIN_PATH . '/inc/twitteroauth/twitteroauth.php' );

/* Shortcode Generator */
require_once ( SM_PLUGIN_PATH . '/inc/shortcode-generator/shortcode-generator.php' );

/* featured post */
require_once ( SM_PLUGIN_PATH . '/inc/featured-post.php' );

/* Shortcodes */
require_once( SM_PLUGIN_PATH . '/shortcodes/shortcodes.php' );

/* Widgets */
require_once ( SM_PLUGIN_PATH . '/inc/widgets/twitter.php' );
//require_once ( SM_PLUGIN_PATH . '/inc/widgets/contact-info.php' );

add_action( 'plugins_loaded', 'sm_load_plugin_textdomain' );
function sm_load_plugin_textdomain() {
	load_plugin_textdomain( 'semona-extension', false, SM_PLUGIN_PATH . '/languages' );
}

/* Register / Enqueue Scripts & styles */
require_once( SM_PLUGIN_PATH . '/inc/static.php' );


add_action('admin_head', 'sm_custom_admin_style');

function sm_custom_admin_style() {
	echo '<style>
    th.column-featured,
    td.column-featured {
		width: 75px;
		text-align: center;
	}
  </style>';
}