<?php

define( 'SM_AUTHOR_SOCIAL_LINK_OPTIONS_ADDED', true );

global $sm_author_social_link_icons;

$sm_author_social_link_icons = array(
		'facebook'		=> esc_html__( 'Facebook', 'semona-extension' ),
		'twitter'		=> esc_html__( 'Twitter', 'semona-extension' ),
		'instagram'		=> esc_html__( 'Instagram', 'semona-extension' ),
		'google-plus'	=> esc_html__( 'Google+', 'semona-extension' ),
		'linkedin'		=> esc_html__( 'LinkedIn', 'semona-extension' ),
		'behance'		=> esc_html__( 'Behance', 'semona-extension' ),
		'pinterest'		=> esc_html__( 'Pinterest', 'semona-extension' ),
		'tumblr'		=> esc_html__( 'Tumblr', 'semona-extension' ),
);

function sm_author_extra_fields( $extra_fields ) {
	global $sm_author_social_link_icons;
	foreach ( $sm_author_social_link_icons as $id => $name ) {
		$extra_fields[$id] = $name;
	}
	return $extra_fields;
}
add_filter( 'user_contactmethods', 'sm_author_extra_fields' );
